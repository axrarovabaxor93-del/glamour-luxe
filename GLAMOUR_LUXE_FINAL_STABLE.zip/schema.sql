create extension if not exists pgcrypto;
create table if not exists public.admins (user_id uuid primary key references auth.users(id) on delete cascade);
alter table public.admins enable row level security;
drop policy if exists "admins read self" on public.admins;
create policy "admins read self" on public.admins for select to authenticated using (user_id = auth.uid());

create or replace function public.is_admin() returns boolean
language sql security definer set search_path = public
stable as $$ select exists (select 1 from public.admins where user_id = auth.uid()); $$;

create table if not exists public.profiles (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references auth.users(id) on delete cascade,
  name text not null,
  city text,
  nationality text,
  languages text[] default '{}',
  bio text,
  photo text,
  photo2 text,
  verified boolean not null default false,
  active boolean not null default true,
  plan text not null default 'basic' check (plan in ('basic','premium','vip')),
  plan_expires_at timestamptz,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
drop policy if exists "public active profiles" on public.profiles;
create policy "public active profiles" on public.profiles for select using (active = true);
drop policy if exists "owners read own profiles" on public.profiles;
create policy "owners read own profiles" on public.profiles for select to authenticated using (owner_id = auth.uid() or public.is_admin());
drop policy if exists "owners create profiles" on public.profiles;
create policy "owners create profiles" on public.profiles for insert to authenticated with check (owner_id = auth.uid());
drop policy if exists "owners update profiles" on public.profiles;
create policy "owners update profiles" on public.profiles for update to authenticated using (owner_id = auth.uid() or public.is_admin()) with check (owner_id = auth.uid() or public.is_admin());

-- After an admin account exists, run:
-- insert into public.admins(user_id) values ('AUTH-USER-UUID-HERE') on conflict do nothing;
