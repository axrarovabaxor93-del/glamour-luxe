GLAMOUR LUXE — FRESH BUILD

1. Deploy worker.js to Cloudflare Workers.
2. Keep the existing Supabase URL/publishable key in wrangler.jsonc.
3. In Cloudflare Worker Settings > Variables and Secrets, add:
   STRIPE_SECRET_KEY = your Stripe test secret key (Secret, never commit it).
4. Run schema.sql in Supabase SQL Editor. Then insert your admin user id into public.admins.
5. The website uses same-origin /api/stripe/checkout and derives Stripe success/cancel URLs from the actual request origin, so preview workers and production workers do not get mixed.
6. Stripe prices are the existing test prices:
   Premium: price_1UMmGKG8lGvV5X1a9aYozK74
   VIP: price_1UMmISG8lGvV5X1a7eOgOIQR

This build is a general premium profile platform. Payments are for platform listing/visibility services, not for sexual services.
